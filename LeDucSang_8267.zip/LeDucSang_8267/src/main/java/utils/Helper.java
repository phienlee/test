package utils;

public class Helper {
    public static String getCurrentDir() {
        String current = System.getProperty("user.dir") + "/";
        return current;
    }
}
