package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Utils {
    public static Properties prop;
    public static WebDriver driver;

    public void propertyInit() {
        prop = new Properties();

        try {
            FileInputStream file = new FileInputStream("src/main/resources/config.properties");
            prop.load(file);
        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public void waitFor(WebElement locator) {
        WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(prop.getProperty("EXPLICIT_WAIT")));
        wait.until(ExpectedConditions.elementToBeClickable(locator));
    }
}
