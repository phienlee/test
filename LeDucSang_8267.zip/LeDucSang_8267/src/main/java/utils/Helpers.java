package utils;

public class Helpers {
    public static String getCurrentDir() {
        String current = System.getProperty("user.dir") + "/";
        return current;
    }

    public static int getRandomNumber(int min, int max){
        return (int) Math.floor(Math.random() *(max - min + 1) + min);
    }
}
