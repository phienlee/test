package page;

import org.openqa.selenium.By;
import web_element.Element;

public class HomePage extends BasePage {
    private Element welcomeMessage = new Element(By.xpath("//div[@id = 'content']/h1[@class = 'heading']"));
    private Element fileDownloadLink = new Element(By.xpath("//a[normalize-space()='File Download']"));

    public HomePage() {
    }

    public String getWelcomeMessage() {
        return welcomeMessage.getText();
    }

    public void clickFileDownloadLink() {
        fileDownloadLink.click();
    }
}
