package page;

import driver.DriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import web_element.Element;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.List;

public class FileDownloaderPage extends BasePage {
    private static String downloadPath = "D:\\seleniumdownloads";
    public WebDriver driver;
    private Element titleLabel = new Element(By.xpath("//div[@id = 'content']/div[@class = 'example']/h3"));
    private Element fileDownloadLink = new Element(By.xpath("//a[normalize-space()='File Download']"));

    public FileDownloaderPage() {
    }

    public String getTitle() {
        return titleLabel.getText();
    }

    public void clickFileDownloadLink() {
        fileDownloadLink.click();
    }

    public static boolean  checkFileExist(String fileName) {
        String path = "C:\\Automation\\Download\\" + fileName;
        File file = new File(path);
        if (file.exists()) {
            System.out.println(path + " is present\n");
            return true;
        } else {
            System.out.println(path + " is not present\n");
            return false;
        }
    }

    public static void deleteFile(String fileName) {
        String path = "C:\\Automation\\Download\\" + fileName;
        try
        {
            if ((new File(path)).delete()) {
                System.out.printf("deleted");
            } else {
                System.out.printf("failed");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
