package page;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import web_element.Element;

public class LoginPage extends BasePage {
    private Element userNameTextBox = new Element(By.id("username"));
    private Element passwordTextBox = new Element(By.id("password"));
    private Element welcomeMessage = new Element(By.xpath("//strong[contains(.,'Welcome')]"));
    private Element errorMessage = new Element(By.xpath("//div[@id='content']//p[@class='message error LoginForm']"));
    private Element loginButton = new Element(By.cssSelector("[type='submit']"));
    private Element loginTabSelected = new Element(By.xpath("//li[@class='selected']//span[text()='Login']"));

    public LoginPage() {
    }

    public void login(String username, String password) {
        userNameTextBox.enter(username);
        passwordTextBox.enter(password);
        loginButton.scrollToViewAndClick();
    }

    public void login(String username, String password, int timeRepeat) {
        for (int i = 0; i < timeRepeat; i++) {
            userNameTextBox.enter(username);
            passwordTextBox.enter(password);
            loginButton.click();
        }
    }

    public BasePage loginSuccess(String username, String password) {
        login(username, password);
        return new BasePage();
    }

    public String getWelcomeMessage() {
        return welcomeMessage.getText();
    }

    public String getErrorMessage() {
        return errorMessage.getText();
    }

    public boolean isLoginTabDisplay() {
        return loginTabSelected.isLocatorDisplay();
    }
}
