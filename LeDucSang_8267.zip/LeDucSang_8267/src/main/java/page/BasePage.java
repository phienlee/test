package page;

import org.openqa.selenium.By;
import web_element.Element;

public class BasePage {
    private String tab = "//div[@id='menu']//span[.='%s']";

    public void selectTab(String tabName) {
        By locator = By.xpath(String.format(this.tab, tabName));
        Element element= new Element(locator);
        element.scrollToViewAndClick();
    }

    public LoginPage openLoginPage() {
        selectTab("Login");
//        log.info("Open login page");
        return new LoginPage();
    }
}
