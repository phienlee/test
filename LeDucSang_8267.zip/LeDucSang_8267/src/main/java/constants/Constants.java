package constants;

public class Constants {
    public static final String CHANGE_PASSWORD_SUCCESSFULLY_MESSAGE = "Your password has been updated!";
    public static final String CHANGE_PASSWORD_ERROR_MESSAGE = "Password change failed. Please correct the errors and try again.";
    public static final String REGISTER_ERROR_MESSAGE = "There're errors in the form. Please correct the errors and try again.";
    public static final String HOMEPAGE_URL = "https://the-internet.herokuapp.com/";
    public static final String USERNAME = "sang.le12345678@gmail.com";
    public static final String PASSWORD = "123456789";
    public static final String WRONG_PASSWORD = "wrong-password";
    public static final String EMAIL_REGISTER = "123456789";
    public static final String PASSWORD_REGISTER = "123456789";
    public static final String CONFIRM_PASSWORD_REGISTER = "123456789";
    public static final String ID_CARD_REGISTER = "123456789";
    public static final String REGISTER_SUCCESSFULLY_MESSAGE = "You're here";
    public static final String VALIDATION_PASSWORD_ERROR_MESSAGE = "Invalid password length";
    public static final String VALIDATION_PID_ERROR_MESSAGE = "Invalid ID length";
}

