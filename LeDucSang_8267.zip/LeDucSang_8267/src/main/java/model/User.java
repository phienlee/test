package model;

import com.github.javafaker.Faker;

public class User {
    private String email;
    private String password;
    private String confirmPassword;
    private String idCard;

    public User() {
    }

    public User(String email, String password, String idCard) {
        this.email = email;
        this.password = password;
        this.idCard = idCard;
    }

    public User(String email, String password, String confirmPassword, String idCard) {
        this.email = email;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.idCard = idCard;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public User generatedUser() {
        Faker faker = new Faker();
        email = faker.internet().safeEmailAddress();
        password = faker.internet().password(8, 32, true);
        idCard = String.valueOf(faker.regexify("[0-9]{8,20}"));
        return new User(email, password, idCard);
    }

    public User generatedUserWithNotSamePasswordConfirm() {
        Faker faker = new Faker();
        email = faker.internet().safeEmailAddress();
        password = faker.internet().password(8, 32, true);
        confirmPassword = faker.internet().password(8, 32, true);
        idCard = String.valueOf(faker.regexify("[0-9]{8,20}"));
        return new User(email, password, confirmPassword, idCard);
    }
}
