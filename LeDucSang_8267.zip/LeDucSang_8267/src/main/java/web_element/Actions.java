package web_element;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Actions {
    private static JavascriptExecutor js;

    public static void enter(WebElement element, String value) {
        element.sendKeys(value);
    }

    public static void scrollAndClickElement(WebDriver driver, WebElement element) {
        js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click()", element);
    }

    public static void selectElement(WebElement element, String value) {
        Select select = new Select(element);
        select.selectByVisibleText(value);
    }
}
