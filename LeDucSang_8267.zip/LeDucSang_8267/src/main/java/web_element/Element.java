package web_element;

import driver.DriverManager;
import lombok.Getter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

@Getter
public class Element {
    protected By locator;
    private static JavascriptExecutor js;

    public Element(By locator) {
        this.locator = locator;
    }

    public WebElement waiForElement() {
        return DriverManager.getDriver().findElement(locator);
    }

    public void enter(String value) {
        DriverManager.getDriver().findElement(locator).sendKeys(value);
    }

    public String getText() {
        return DriverManager.getDriver().findElement(locator).getText();
    }

    public void click() {
        DriverManager.getDriver().findElement(locator).click();
    }

    public void scrollToViewAndClick() {
        js = (JavascriptExecutor) DriverManager.getDriver();
        js.executeScript("arguments[0].click()", waiForElement());
    }

    public boolean isLocatorDisplay() {
        return DriverManager.getDriver().findElement(locator).isDisplayed();
    }

    public void selectElement(String value) {
        Select select = new Select(this.waiForElement());
        select.selectByVisibleText(value);
    }

    public String getDropdownSelectionText() {
        Select select = new Select(this.waiForElement());
        return select.getFirstSelectedOption().getText();
    }
}
