package test;

import constants.Constants;
import driver.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseTest {
    WebDriver driver = DriverManager.getBrowserDriver();

    @BeforeClass
    public void setUp() {
        System.out.println("Start browser");
        driver.manage().window().maximize();
        driver.get(Constants.HOMEPAGE_URL);
    }

//    @AfterClass
//    public void tearDownTestBase() {
//        if (null != driver) {
//            driver.quit();
//            driver = null;
//        }
//    }
}
