package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import page.FileDownloaderPage;
import page.HomePage;
import utils.Helpers;
import utils.PropertiesHelper;
import web_element.Element;

import java.io.IOException;
import java.util.List;

public class VerifyDownloadTest extends BaseTest {
    @Test(description = "Verify download file")
    public void verifyDownloadTest() throws IOException {
        System.out.println(PropertiesHelper.getValue("chromeDriverUrl"));
        HomePage homePage = new HomePage();
        FileDownloaderPage fileDownloaderPage = new FileDownloaderPage();
        Assert.assertEquals(
                homePage.getWelcomeMessage(),
                "Welcome to the-internet",
                "Verify homepage displays");
        homePage.clickFileDownloadLink();
        Assert.assertEquals(
                fileDownloaderPage.getTitle(),
                "File Downloader",
                "Verify file downloader title displays");
        List<WebElement> elements = driver.findElements(By.xpath("//div[@id='content']/div[@class='example']/a"));
        System.out.println(elements.size());
//        Assert.assertEquals(
//                elements.size(),
//                25,
//                "Verify no of downloader");
        String fileName = elements.get(1).getText();
        String randomDownloadLinkLocator = String.format("//div[@id='content']/div[@class='example']/a[%s]", Helpers.getRandomNumber(1, elements.size() + 1));
        System.out.println(randomDownloadLinkLocator);
        Element randomLink = new Element(By.xpath(randomDownloadLinkLocator));
        String randomFileName = randomLink.getText();
        Assert.assertFalse(FileDownloaderPage.checkFileExist(randomFileName));
        randomLink.click();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        System.out.println(randomFileName);
        Assert.assertTrue(FileDownloaderPage.checkFileExist(randomFileName));
        FileDownloaderPage.deleteFile(fileName);
        Assert.assertFalse(FileDownloaderPage.checkFileExist(randomFileName));
    }
}
